define([ 'appGlobal' ], function() {
	var appGlobal = {
			accesstoken:"",
            country:"Netherlands",
			apiKey: "Qh4ZiuGbV5oYhxJAA84buwOLnkG9z2dy",
            userId: "",
            personData:undefined,
	};

	return appGlobal;
});