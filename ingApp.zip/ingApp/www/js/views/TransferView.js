/*** author: @anotherwebstorm */
/**
 * -> Home View
 */
define([ 'jquery', 'underscore', 'backbone', 'Handlebars', 'jquerymobile',
		'router', 'text!templates/TransferTmp.html','appGlobal' ], function($, _, Backbone,
		hbs, jquerymobile, Router, currentTemplate,appGlobal) {
    var ref = '';
	var TransferView = Backbone.View.extend({

		el : '.app > .container-narrow',

		template : hbs.compile(currentTemplate),

		events : {
			 
		},
        
		initialize : function() {

			this.render();
		 	$(this.el).trigger('create');

		},

		render : function() { 
			$(this.el).html(this.template());

		}

	});
	return TransferView;
});


 